// SPDX-License-Identifier: GPL-3.0-or-later
package rongyi.lingbai.wechatpanel
internal object HomeSidePanelLayoutStore {

    fun load(): HomeSidePanelLayoutLoad {
        val legacy = LegacyHomeSidePanelSnapshot(
            weatherCity = HomeSidePanelPreferences.legacySelectedWeatherCity,
            hideWalletBalance = HomeSidePanelPreferences.legacyHideWalletBalance,
            hitokotoSettings = HomeSidePanelPreferences.legacyHitokotoSettings,
        )
        val raw = HomeSidePanelPreferences.layoutRaw
        if (raw != null) {
            return HomeSidePanelLayoutCodec.load(raw, legacy, UuidHomeSidePanelIdGenerator).also { loaded ->
                if (loaded is HomeSidePanelLayoutLoad.Fallback) {
                    WeLogger.w(TAG, "invalid saved side panel layout; using an in-memory fallback")
                }
            }
        }
        val layout = defaultHomeSidePanelLayout(legacy)
        save(layout).getOrThrow()
        return HomeSidePanelLayoutLoad.Migrated(layout)
    }

    fun save(layout: HomeSidePanelLayout): Result<Unit> = runCatching {
        HomeSidePanelPreferences.layoutRaw = HomeSidePanelLayoutCodec.encode(layout)
    }

    fun loadWeatherCache(cardId: String): WeatherCardCacheRecord? =
        decodeCache(HomeSidePanelPreferenceKeys.CARD_WEATHER_CACHE_PREFIX + cardId)

    fun saveWeatherCache(cardId: String, record: WeatherCardCacheRecord): Result<Unit> =
        encodeCache(HomeSidePanelPreferenceKeys.CARD_WEATHER_CACHE_PREFIX + cardId, record)

    fun loadHitokotoCache(cardId: String): HitokotoCardCacheRecord? =
        decodeCache(HomeSidePanelPreferenceKeys.CARD_HITOKOTO_CACHE_PREFIX + cardId)

    fun saveHitokotoCache(cardId: String, record: HitokotoCardCacheRecord): Result<Unit> =
        encodeCache(HomeSidePanelPreferenceKeys.CARD_HITOKOTO_CACHE_PREFIX + cardId, record)

    fun removeCardCaches(cardId: String) {
        PanelHostContext.preferences.edit()
            .remove(HomeSidePanelPreferenceKeys.CARD_WEATHER_CACHE_PREFIX + cardId)
            .remove(HomeSidePanelPreferenceKeys.CARD_HITOKOTO_CACHE_PREFIX + cardId)
            .apply()
    }

    fun migrateLegacyCaches(layout: HomeSidePanelLayout) {
        HomeSidePanelPreferences.legacyWeatherLastSuccess?.let { snapshot ->
            val card = layout.cards.filterIsInstance<WeatherCardConfig>().firstOrNull {
                weatherCacheFingerprint(it.city) == weatherCacheFingerprint(snapshot.city)
            }
            if (card != null) {
                if (loadWeatherCache(card.id) == null) {
                    saveWeatherCache(
                        card.id,
                        WeatherCardCacheRecord(weatherCacheFingerprint(card.city), snapshot),
                    ).getOrThrow()
                }
            }
        }

        HomeSidePanelPreferences.legacyHitokotoLastSuccess?.let { snapshot ->
            val legacyFingerprint = hitokotoCacheFingerprint(HomeSidePanelPreferences.legacyHitokotoSettings)
            val card = layout.cards.filterIsInstance<HitokotoCardConfig>().firstOrNull {
                hitokotoCacheFingerprint(it.settings) == legacyFingerprint
            }
            if (card != null) {
                if (loadHitokotoCache(card.id) == null) {
                    saveHitokotoCache(
                        card.id,
                        HitokotoCardCacheRecord(legacyFingerprint, snapshot),
                    ).getOrThrow()
                }
            }
        }
    }

    private inline fun <reified T> decodeCache(key: String): T? =
        PanelHostContext.preferences.getString(key, null)?.let { raw ->
            runCatching { DefaultJson.decodeFromString<T>(raw) }.getOrNull()
        }

    private inline fun <reified T> encodeCache(key: String, value: T): Result<Unit> =
        runCatching {
            check(
                PanelHostContext.preferences.edit()
                    .putString(key, DefaultJson.encodeToString(value))
                    .commit(),
            ) { "failed to persist $key" }
        }

    private const val TAG = "HomeSidePanelLayoutStore"
}
